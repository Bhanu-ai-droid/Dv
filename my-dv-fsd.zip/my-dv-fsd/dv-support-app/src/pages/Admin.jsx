function Admin() {
  return (
    <div>

      <h2>Admin Dashboard</h2>

      <ul>
        <li>Manage Users</li>
        <li>Manage Resources</li>
        <li>Ensure Data Security</li>
      </ul>

    </div>
  );
}

export default Admin;
