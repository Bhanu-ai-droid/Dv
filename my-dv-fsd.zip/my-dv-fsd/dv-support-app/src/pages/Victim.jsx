function Victim() {
  return (
    <div>

      <h2>Victim Support</h2>

      <button>Request Help</button>

      <button>View Legal Resources</button>

    </div>
  );
}

export default Victim;
