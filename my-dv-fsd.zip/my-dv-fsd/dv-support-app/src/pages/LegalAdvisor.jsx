function LegalAdvisor() {
  return (
    <div>

      <h2>Legal Advisor Dashboard</h2>

      <ul>
        <li>Provide Legal Advice</li>
        <li>Update Legal Resources</li>
        <li>Assist Legal Actions</li>
      </ul>

    </div>
  );
}

export default LegalAdvisor;
