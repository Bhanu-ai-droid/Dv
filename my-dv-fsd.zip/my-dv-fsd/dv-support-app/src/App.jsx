import { BrowserRouter, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";

import Home from "./pages/Home";
import Admin from "./pages/Admin";
import Victim from "./pages/Victim";
import Counsellor from "./pages/Counsellor";
import LegalAdvisor from "./pages/LegalAdvisor";

function App() {

  return (

    <BrowserRouter>

      <Navbar />

      <div style={{ padding: "20px" }}>

        <Routes>

          <Route path="/" element={<Home />} />

          <Route path="/admin" element={<Admin />} />

          <Route path="/victim" element={<Victim />} />

          <Route path="/counsellor" element={<Counsellor />} />

          <Route path="/legal" element={<LegalAdvisor />} />

        </Routes>

      </div>

    </BrowserRouter>

  );
}

export default App;
