function Counsellor() {
  return (
    <div>

      <h2>Counsellor Dashboard</h2>

      <ul>
        <li>View Victim Requests</li>
        <li>Provide Guidance</li>
        <li>Track Progress</li>
      </ul>

    </div>
  );
}

export default Counsellor;
